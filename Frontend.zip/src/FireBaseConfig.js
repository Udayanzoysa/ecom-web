// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyB1HKin7znfkW2xuMjYq-hxwzfcNfEn4_M",
    authDomain: "e-commerce-v1-18dce.firebaseapp.com",
    projectId: "e-commerce-v1-18dce",
    storageBucket: "e-commerce-v1-18dce.appspot.com",
    messagingSenderId: "1030052597184",
    appId: "1:1030052597184:web:0e41a4eab0d67650accc25",
    measurementId: "G-JY8TTWX00F"
};

export default  firebaseConfig
