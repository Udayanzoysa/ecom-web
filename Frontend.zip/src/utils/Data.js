  export const services = [
    {
        title: "Free Shipping",
        tagline: "From all orders over $5",
        image: "images/service.png",
    },
    {
        title: "Support 24/7",
        tagline: "Shop with an Expert",
        image: "images/service-03.png",
    },
    {
        title: "Affordable Prices",
        tagline: "Get factory default price",
        image: "images/service-04.png",
    },
    {
        title: "Secure Payment",
        tagline: "100% protected payment",
        image: "images/service-05.png",
    },
  ];